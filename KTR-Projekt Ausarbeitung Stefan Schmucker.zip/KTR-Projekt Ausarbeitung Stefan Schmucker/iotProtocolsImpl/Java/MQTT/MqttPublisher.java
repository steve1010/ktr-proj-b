import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttPublisher {

    private final String topic;
    private final String broker;
    private final int QoS = 1;
    private final String msg;
    private MemoryPersistence persistence = new MemoryPersistence();

    private MqttPublisher(String broker, String nachricht, String topic) {
        this.broker = broker;
        this.msg = nachricht;
        this.topic = topic;
    }

    private void publish() {
        try {
            MqttClient client = new MqttClient(broker, MqttClient.generateClientId(), persistence);
            MqttConnectOptions conOps = new MqttConnectOptions();
            conOps.setCleanSession(true);
            conOps.setUserName("raspberry");
            conOps.setPassword("pi".toCharArray());
            client.connect(conOps);
            MqttMessage toSend = new MqttMessage(msg.getBytes());
            toSend.setQos(this.QoS);
            client.publish(topic, toSend);
            client.disconnect();
        } catch (MqttException e) {
            e.printStackTrace();

        }
    }

    public static void main(String[] args) throws InterruptedException {
        String brokerURL = "tcp://" + args[0] + ":1883";
        MqttPublisher sender = new MqttPublisher(brokerURL, "hello", "hello");
        while (true) {
            Thread.sleep(25000);
            System.out.println("publishing msg 'hello' to " + brokerURL + ", topic: 'hello'.");
            sender.publish();
        }
    }

}
