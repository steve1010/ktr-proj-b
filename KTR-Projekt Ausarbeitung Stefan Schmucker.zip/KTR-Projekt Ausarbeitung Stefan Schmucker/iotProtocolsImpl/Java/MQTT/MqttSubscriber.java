import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.eclipse.paho.client.mqttv3.MqttException;

public class MqttSubscriber implements MqttCallback {

    private final String topic;
    private final int qos = 2;
    private final String brokerIP;
    private final String userName = "raspberry";
    MemoryPersistence persistence = new MemoryPersistence();

    public MqttSubscriber(String brokerIP, String topic) {
        this.brokerIP = brokerIP;
        this.topic = topic;
    }

    public void subscribe() {
        try {
            MqttClient client = new MqttClient(brokerIP, MqttClient.generateClientId(), persistence);
            MqttConnectOptions conOps = new MqttConnectOptions();
            conOps.setCleanSession(true);
            conOps.setUserName(userName);
            conOps.setPassword("pi".toCharArray());
            client.connect(conOps);
            client.setCallback(this);
            client.subscribe(topic, qos);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void connectionLost(Throwable t) {
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        System.out.println("Msg arrived: ´" + message.toString() + '´');
    }

    public static void main(String[] args) throws MqttException {
        String brokerURL = "tcp://" + args[0] + ":1883";
        MqttSubscriber sub = new MqttSubscriber(brokerURL, "hello");
        sub.subscribe();
    }
}
