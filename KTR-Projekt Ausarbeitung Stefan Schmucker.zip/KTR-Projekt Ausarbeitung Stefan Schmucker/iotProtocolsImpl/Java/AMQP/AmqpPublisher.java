package amqp;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class AMQPPublisher {

    private static String QUEUE_NAME;
    private static String HOST_NAME;

    public AMQPPublisher(String host) {
        QUEUE_NAME = "hello";
        HOST_NAME = host;
    }

    public void publish(String msg) throws IOException, TimeoutException {

        // create connection to the server
        ConnectionFactory factory = new ConnectionFactory();
        factory.setUsername("pi");
        factory.setPassword("raspberry");
        factory.setHost(HOST_NAME);
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // declare a sending queue where we can publish messages
        channel.queueDeclare(QUEUE_NAME, false, false, false, null);
        channel.basicPublish("", QUEUE_NAME, null, msg.getBytes());
        System.out.println(" [x] Sent '" + msg + "'");

        // close the channel and connection
        channel.close();
        connection.close();
    }

    public static void main(String[] args) throws IOException, TimeoutException, InterruptedException {
        if (args.length != 1) { // further validations could be added.
            throw new IllegalArgumentException("Faulty usage: Only the host IP shall be passed.");
        }
        AMQPPublisher pub = new AMQPPublisher(args[0]);
        while (true) {
            pub.publish("hello");
            Thread.sleep(35000);
        }
    }

}
