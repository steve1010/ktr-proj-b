package app.amqp;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.Observable;
import java.util.concurrent.TimeoutException;

public class AMQPSubscriber extends Observable {

	private final String QUEUE_NAME;
	private final String hostName;

	public AMQPSubscriber(String hostName) {
		this.QUEUE_NAME = "hello";
		this.hostName=hostName;
	}

	public void subscribe() {

		// open a channel and connection
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(hostName);
        factory.setUsername("pi");
        factory.setPassword("password");
		try {
			Connection connection = factory.newConnection();
			Channel channel = connection.createChannel();
			// declare consuming queue - matching with the sender queue !
			channel.queueDeclare(QUEUE_NAME, false, false, false, null);
			System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

			// provide a callback buffering the msgs
			Consumer consumer = new DefaultConsumer(channel) {
				@Override
				public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties,
						byte[] body) throws IOException {
					String msg = new String(body, "UTF-8");
					System.out.println(" [x] Received '" + msg + "'");
					setChanged();
					notifyObservers(msg);
				}
			};
			channel.basicConsume(QUEUE_NAME, true, consumer);
		} catch (IOException | TimeoutException e) {
			e.printStackTrace();
			
		}
	}

	public static void main(String[] args) {
		if (args.length != 1) { // further validations could be added.
			throw new IllegalArgumentException("Faulty usage: Only the host IP shall be passed.");
		}
		AMQPSubscriber sub = new AMQPSubscriber(args[0]);
		sub.subscribe();
	}
}
