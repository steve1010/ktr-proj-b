package app;

import org.jivesoftware.smack.*;
import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatManager;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.roster.Roster;
import org.jivesoftware.smack.roster.RosterEntry;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;

public class XmppSender implements ChatMessageListener {

    AbstractXMPPConnection connection;

    public void login(String serverIP, String userName, String password) {

        XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
                .setUsernameAndPassword(userName, password)
                .setServiceName("localhost")
                .setHost(serverIP)
                .setPort(5222)
                .allowEmptyOrNullUsernames()
                .setSecurityMode(ConnectionConfiguration.SecurityMode.disabled) // Do not disable TLS except for test purposes!
                .setDebuggerEnabled(true)
                .build();

        connection = new XMPPTCPConnection(config);
        try {
            connection.connect();
            connection.login();
        } catch (SmackException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XMPPException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sends the specified text as a message to the other chat participant.
     *
     * @param message
     * @param to
     * @throws XMPPException
     * @throws SmackException.NotConnectedException
     */
    public void sendMessage(String message, String to) throws XMPPException, SmackException.NotConnectedException {
        ChatManager chatManager = ChatManager.getInstanceFor(connection);
        Chat chat = chatManager.createChat(to, this); // pass XmppClient instance as listener for received messages.
        chat.sendMessage(message);
    }

    /**
     * Displays received messages
     */
    public void processMessage(Chat chat, Message message) {
        if (message.getType() == Message.Type.chat) {
            System.out.println(chat.getParticipant() + " says: " + message.getBody());
        }
    }

    /**
     * Displays users (entries) in the roster
     */
    public void displayBuddyList() {
        Roster roster = Roster.getInstanceFor(connection);
        Collection<RosterEntry> entries = roster.getEntries();

        System.out.println("\n\n" + entries.size() + " buddy(ies):");
        for (RosterEntry r : entries) {
            String user = r.getUser();
            Presence.Type presenceType = roster.getPresence(user).getType();
            System.out.println(user + ":" + presenceType);
        }
    }

    public void disconnect() {
        connection.disconnect();
    }

    public static void main(String args[]) throws Exception {
        if (args == null) {
            throw new IllegalArgumentException("Args must not be null");
        }
        if (args.length != 3) {
            throw new IllegalArgumentException("USAGE: 1st arg: server IP, 2nd arg: userName,  3rd arg: password.");
        }
        SmackConfiguration.DEBUG = true;
        app.XmppClient client = new app.XmppClient();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        //  login information here
        client.login(args[0], args[1], args[2]);

        System.out.println("Who do you want to talk to? - Type contacts full email address:");
        String talkTo = br.readLine();

        System.out.println("All messages will be sent to " + talkTo);
        System.out.println("initiating sending loop \t (1msg/40sec)..\n\n");
        String msg = "Hello Xmpp";
        while (true) {
            client.sendMessage(msg, talkTo);
            Thread.sleep(40000);
        }
    }
}
