package app;

import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.ConnectionConfiguration.SecurityMode;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.SmackException.NotConnectedException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatManager;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence.Type;
import org.jivesoftware.smack.roster.Roster;
import org.jivesoftware.smack.roster.RosterEntry;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;

public class Client implements ChatMessageListener {

    AbstractXMPPConnection connection;

    public void login(String serverIP, String userName, String password) {

        XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
                .setUsernameAndPassword(userName, password)
                .setServiceName("localhost")
                .setHost(serverIP)
                .setPort(5222)
                .allowEmptyOrNullUsernames()
                .setSecurityMode(SecurityMode.disabled) // Do not disable TLS except for test purposes!
                .setDebuggerEnabled(true)
                .build();

        connection = new XMPPTCPConnection(config);
        try {
            connection.connect();
            connection.login();
        } catch (SmackException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XMPPException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sends the specified text as a message to the other chat participant.
     *
     * @param message
     * @param to
     * @throws XMPPException
     * @throws NotConnectedException
     */
    public void sendMessage(String message, String to) throws XMPPException, NotConnectedException {
        ChatManager chatManager = ChatManager.getInstanceFor(connection);
        Chat chat = chatManager.createChat(to, this); // pass XmppClient instance as listener for received messages.
        chat.sendMessage(message);
    }

    /**
     * Displays received messages
     */
    public void processMessage(Chat chat, Message message) {
        if (message.getType() == Message.Type.chat) {
            System.out.println(chat.getParticipant() + " says: " + message.getBody());
        }
    }

    /**
     * Displays users (entries) in the roster
     */
    public void displayBuddyList() {
        Roster roster = Roster.getInstanceFor(connection);
        Collection<RosterEntry> entries = roster.getEntries();

        System.out.println("\n\n" + entries.size() + " buddy(ies):");
        for (RosterEntry r : entries) {
            String user = r.getUser();
            Type presenceType = roster.getPresence(user).getType();
            System.out.println(user + ":" + presenceType);
        }
    }

    public void disconnect() {
        connection.disconnect();
    }

    public static void main(String args[]) throws Exception {
        if (args == null) {
            throw new IllegalArgumentException("Args must not be null");
        }
        if (args.length != 3) {
            throw new IllegalArgumentException("USAGE: 1st arg: server IP, 2nd arg: userName,  3rd arg: password.");
        }
        SmackConfiguration.DEBUG = true;
        Client client = new Client();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String msg;

        // Enter your login information here
        client.login(args[0], args[1], args[2]);

        // Display online users
        client.displayBuddyList();

        System.out.println("Who do you want to talk to? - Type contacts full email address:");
        String talkTo = br.readLine();

        System.out.println("All messages will be sent to " + talkTo);
        System.out.println("Enter your message in the console:");
        System.out.println("-----\n");

        while (!(msg = br.readLine()).equals("bye")) {
            client.sendMessage(msg, talkTo);
        }

        client.disconnect();
        System.exit(0);
    }

}
