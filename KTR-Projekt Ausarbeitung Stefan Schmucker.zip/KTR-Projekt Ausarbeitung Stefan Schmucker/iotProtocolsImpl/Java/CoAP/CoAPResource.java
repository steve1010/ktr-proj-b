package coap.app;

import static org.eclipse.californium.core.coap.CoAP.ResponseCode.*;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.server.resources.CoapExchange;

public class CoAPResource extends CoapResource {

    private final String getMsg;

    public CoAPResource(String in) {
        super(in);
        this.getMsg = in;
    }

    @Override
    public void handleGET(CoapExchange exchange) {
        exchange.respond(CONTENT, getMsg); // reply with 2.05 payload (text/plain)
    }

    @Override
    public void handlePOST(CoapExchange exchange) {
        exchange.accept(); // make it a separate response
        exchange.respond(CREATED); // reply with response code only (shortcut)
    }
}