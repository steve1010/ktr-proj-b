﻿package coap.app;

import org.eclipse.californium.core.CoapClient;

public class CoAPSubscriber {
    public static void main(String[] args) throws InterruptedException {
        if (args == null || args.length != 1) {
            throw new IllegalArgumentException("IP shall be passed as argument.");
        }
        CoapClient client = new CoapClient("coap://" + args[0] + ":5683/randomTemperature");
        Thread.sleep(5000);
        while (true) {
            String text = client.get().getResponseText(); // blocking call
            System.err.println("The temperature is currently: ´" + text + '´');
            Thread.sleep(35000);
        }
    }
}