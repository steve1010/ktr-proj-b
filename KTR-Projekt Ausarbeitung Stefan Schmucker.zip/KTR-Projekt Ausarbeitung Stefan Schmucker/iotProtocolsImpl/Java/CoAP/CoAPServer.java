package coap.app;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.core.network.CoapEndpoint;
import org.eclipse.californium.core.network.EndpointManager;
import org.eclipse.californium.core.network.config.NetworkConfig;
import org.eclipse.californium.core.server.resources.CoapExchange;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;


public class CoAPServer extends CoapServer {

    private static final int COAP_PORT = NetworkConfig.getStandard().getInt(NetworkConfig.Keys.COAP_PORT);

    /*
     * Application entry point.
     */
    public static void main(String[] args) {
        // create server
        CoAPServer server = new CoAPServer();
        // add endpoints on all IP addresses
        server.addEndpoints();
        server.start();
    }

    /**
     * Add individual endpoints listening on default CoAP port on all IPv4 addresses of all network interfaces.
     */
    private void addEndpoints() {
        for (InetAddress addr : EndpointManager.getEndpointManager().getNetworkInterfaces()) {
            // only binds to IPv4 addresses and localhost
            if (addr instanceof Inet4Address || addr.isLoopbackAddress()) {
                InetSocketAddress bindToAddress = new InetSocketAddress(addr, COAP_PORT);
                addEndpoint(new CoapEndpoint(bindToAddress));
            }
        }
    }

    /*
     * Constructor for a new CoAP server. Here, the resources
     * of the server are initialized.
     */
    public CoAPServer() {

        // provide an instance of a Random Temperature resource
        add(new RandomTemperatureResource());
    }

    /*
     * Definition of the Random Temperature Resource
     */
    class RandomTemperatureResource extends CoapResource {

        public RandomTemperatureResource() {
            // set resource identifier
            super("randomTemperature");

            // set display name
            getAttributes().setTitle("Random Temperature Resource");
        }

        @Override
        public void handleGET(CoapExchange exchange) {

            // respond to the request
            exchange.respond(String.valueOf((int) (Math.random() * 50)));
        }
    }
}