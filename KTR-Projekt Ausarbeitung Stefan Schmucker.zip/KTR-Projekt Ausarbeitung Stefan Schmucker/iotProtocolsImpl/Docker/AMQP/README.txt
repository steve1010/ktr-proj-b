This AMQP test application is implemented using RabbitMQ

Alternative: Use RabbitMQ base image & install Java
Alterive: Use OpenJDK base image and install Erlang & RabbitMQ

AMQP default port: 5672

Server IP Address has to be inspected and passed to the container at runtime or added in Dockerfile.
(PUBLISHER/SUBSCRIBER)